import Blog from "../model/Blog.js";
import User from "../model/User.js";

//the job of the controller is to filter

// Fetch all blogs
const getAllBlogs = async function (req, res, next) {
    let blogs;
    try {
        blogs = await Blog.find();
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: "Server error" });
    }

    if (!blogs || blogs.length === 0) {
        return res.status(404).json({ message: "No content found" });
    }

    return res.status(200).json({ blogs });
};

// Add a new blog
const addBlog = async function (req, res, next) {
    const { title, description, image, user } = req.body;
    
    // Check if the user exists
    let existingUser;
    try {
        existingUser = await User.findById(user);
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: "Finding user failed" });
    }

    if (!existingUser) {
        return res.status(404).json({ message: "User not found" });
    }

    const blog = new Blog({
        title,
        description,
        image,
        user
    });

    try {
        const session=await mongoose.startSession();
        session.startTransaction();
        await blog.save();
        existingUser.blogs.push(blog);
        existingUser.save({session});
        await session.commitTransaction();
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: "Failed to save the blog" });
    }

    return res.status(201).json({ blog });
};

// Update an existing blog
const updateBlog = async function (req, res, next) {
    const { title, description } = req.body;
    const blogId = req.params.id;

    let blog;
    try {
        blog = await Blog.findByIdAndUpdate(blogId, {
            title,
            description
        }, { new: true });  // Return the updated document
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: "Unable to update" });
    }

    if (!blog) {
        return res.status(404).json({ message: "Blog not found" });
    }

    return res.status(200).json({ blog });
};

// Get a blog by ID
const getById = async function (req, res, next) {
    const id = req.params.id;

    let blog;
    try {
        blog = await Blog.findById(id);
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: "Error retrieving blog" });
    }

    if (!blog) {
        return res.status(404).json({ message: "Blog not found" });
    }

    return res.status(200).json({ blog });
};

// Delete a blog by ID
const deleteById = async function (req, res, next) {
    const id = req.params.id;

    let blog;
    try {
        blog = await Blog.findByIdAndRemove(id).populate('user');
        await blog.user.blogs.pull(blog);
        await blog.user.save();
    } catch (err) {
        console.error(err);
        return res.status(500).json({ message: "Error deleting blog" });
    }

    if (!blog) {
        return res.status(404).json({ message: "Blog not found" });
    }

    return res.status(200).json({ message: "Blog deleted successfully" });
};

const getByUserId=async function(req,res,next){
    const userId=req.params.id;
    let userBlogs;
    try{
        userBlogs=await User.findById(userId).populate("blogs");
    }catch(err){
        return console.log(err);
    }

    if(!userBlogs){
        return res.status(404).json({message:"User not found"});
    }

    return res.status(200).json({blogs:userBlogs})
}
export { getAllBlogs, addBlog, updateBlog, getById, deleteById, getByUserId};
