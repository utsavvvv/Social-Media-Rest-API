import express from 'express';
import mongoose from 'mongoose';
import router from './routes/user-routes.js';
import blogRouter from './routes/blog-routes.js';
const app = express();
app.use(express.json());
const PORT = 5000;

//job of view is to arrange the data which has been passed on from the controller

app.use("/api/user", router) ;
app.use("/api/blog", blogRouter);
mongoose.connect('mongodb+srv://admin:vc6kaxiysJPXghSi@cluster0.u734gef.mongodb.net/Blog?retryWrites=true&w=majority&appName=Cluster0')
    .then(function() {
        app.listen(PORT, function() {
            console.log(`Server is running at port ${PORT}`);
        });
    })
    .catch(function(err) {
        console.log('Error connecting to MongoDB:', err);
    });




//Password: vc6kaxiysJPXghSi